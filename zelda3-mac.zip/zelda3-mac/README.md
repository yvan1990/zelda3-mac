# zelda3-mac
Simple self-contained launcher for snesrev's zelda3
————————————————————————————————————————————————————

To get started, compile zelda3 from https://github.com/snesrev/zelda3

After compiling, right-click on the zelda3.app file in this folder.

Select "Show Package Contents"

Go to "Contents", then "Resources".

Next, copy the following files from your build of zelda3 to the "Resouces" folder:
	zelda3
	zelda3.ini
	zelda3_assets.dat

Finally, go to the "MacOS" folder in the contents folder, and drag-and-drop the "zelda3" file into the terminal and run it. (This is only necessary for the first run.)

After this, you can just open "zelda3.app" as a normal application.

Enjoy!
